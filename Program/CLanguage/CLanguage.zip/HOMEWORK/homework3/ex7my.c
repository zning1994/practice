#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#define EP 1e-8
int main()
{
    double a,b,c;
    double x1,x2,x3,x4;
    double delta,delta1;
    int j,k,m,n;
    while(scanf("%lf",&a)!=EOF)
    {
        if(a>-EP&&a<EP)
            break;
        else
        {
            delta=b*b-4*a*c;
            if(a>EP)
            {
                if(a>-(EP+1)&&a<EP-1)
                {

                }
            }
//            scanf("%lf%lf",&b,&c);
////            if()
        }
    }
return 0;
}
