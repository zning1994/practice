#include<stdio.h>
#include<string.h>
int main()
{
    long long int k,a,b,c;
    scanf("%d",a);
    while(a>0)
    {
        scanf("%lld",k);

    }
    return 0;
}
