#include<stdio.h>
#include<math.h>
int main()
{
 double n;
 while(scanf("%lf",&n)!=EOF)
 {
  printf("%lf\n",fabs(n));
 }
}
