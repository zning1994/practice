#include<stdio.h>
int main()
{
    char a,b,c;
    scanf("%c%c%c",&a,&b,&c);
    printf("%.3d %.3o %.3x\n",a,a,a);
    printf("%.3d %.3o %.3x\n",b,b,b);
    printf("%.3d %.3o %.3x\n",c,c,c);
    return 0;
}
