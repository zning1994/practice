#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    int i,j,k,true=0;
    char ss;
    scanf("%s",ss);
    printf("Abbreviation ==> Full Name");

    return 0;
}
