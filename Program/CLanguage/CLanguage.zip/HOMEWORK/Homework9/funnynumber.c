#include<stdio.h>
int main()
{
int j,i;
 for(i =1;++i<1000000;i-j||printf("%d ",i ))
 for(j=1;i%++j;);
 return 0;
}
