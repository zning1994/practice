#include<stdio.h>
#include<math.h>
int main()
{
    double x,y;
    scanf("%lf",&x);
    y=log(x)/log(2);
    printf("%.0lf",y);
    return 0;
}
