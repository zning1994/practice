#include<srdio.h>
#define N 10000
int main()
{
    int grade,b,i,num[N];
    while(scanf("%d",&grade)!=EOF)
    {
        if(grade<0||grade>100)
            continue;
        else
        {


        }
    }
}
