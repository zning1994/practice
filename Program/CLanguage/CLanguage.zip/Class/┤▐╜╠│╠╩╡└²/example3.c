#include<stdio.h>
#include"string.h"
int main()
{
    char x[25],y[15];
    int z,w;
    scanf("%s",x);
    scanf("%s",y);
    printf("%s\n%s\n",x,y);
    strcat
}
