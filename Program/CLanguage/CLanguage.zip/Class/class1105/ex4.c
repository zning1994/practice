//������
#include<stdio.h>
#define N 9999999999999999
int m[N]
int main()
{
    int a,b,i,j;
    while(scanf("%d",&a)!=)
    {
        for()
    }

    return 0;
}
