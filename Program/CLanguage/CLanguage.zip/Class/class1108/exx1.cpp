#include<iostream>
using namespace std;
int main()
{
    int a,b,c;
    cin>>a>>b;
    cout<<"The number "<<a<< " and "<<b<<" added is "<<a+b<<endl;
    return 0;
}
