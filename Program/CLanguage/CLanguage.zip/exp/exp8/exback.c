#include<stdio.h>
#include<string.h>
int main()
{
    char *ss;
    int j,len=0;
    int a=0,e=0,i=0,o=0,u=0,p=1,sum=0;
        printf("%.4lf\n",1.0);
        printf("%.4lf\n",111.0);
    }
