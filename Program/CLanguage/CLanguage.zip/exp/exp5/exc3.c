#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main()
{

    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    int t,s,N,i=0,j=0,j1,true1=0,true2=0,l=0,big;
    int lo,hi,be;
    scanf("%d%d%d",&t,&s,&N);
    int low[N],high[N],b[N],m[N],n[N],k[N];
    for(i=0; i<N; i++){
        scanf("%d%d%d",&lo,&hi,&be);
        if(t>=)
        }
    printf("All the dress are inappropriate. Buy new one!\n");
    printf("All the dress are ugly. Buy new one!\n");
    printf("Choose %d dress.\n",big);
    return 0;

}
